

<?php $__env->startSection('template_title'); ?>
    <?php echo e($dataDiri->name ?? 'Show Data Pelamar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Data Pelamar</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('data-diri.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-primary">
                                    <div class="card-header">
                                        <h3 class="card-title">Data Pribadi</h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group">
                                            <strong>User Id:</strong>
                                            <?php
                                                $user = DB::table('users')->where('id', $dataDiri->user_id)->first();
                                            ?>
                                            <?php if($user != null): ?>
                                                <?php echo e($user->name); ?>

                                            <?php else: ?>
                                                Tidak Ada
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <strong>Nama Lengkap:</strong>
                                            <?php echo e($dataDiri->nama_lengkap); ?>

                                        </div>
                                        <div class="form-group">
                                            <strong>Tempat Lahir:</strong>
                                            <?php echo e($dataDiri->tempat_lahir); ?>

                                        </div>
                                        <div class="form-group">
                                            <strong>Tgl Lahir:</strong>
                                            <?php echo e($dataDiri->tgl_lahir); ?>

                                        </div>
                                        <div class="form-group">
                                            <strong>Alamat:</strong>
                                            <?php echo e($dataDiri->alamat); ?>

                                        </div>
                                        <div class="form-group">
                                            <strong>No Hp:</strong>
                                            <?php echo e($dataDiri->no_hp); ?>

                                        </div>
                                        <div class="form-group">
                                            <strong>Email:</strong>
                                            <?php echo e($dataDiri->email); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card card-danger">
                                    <div class="card-header">
                                        <h3 class="card-title">Foto</h3>
                                    </div>
                                    <div class="card-body">
                                        <center>
                                            <img src="<?php echo e(asset('img/foto/'.$dataDiri->foto)); ?>" style="width: 280px" alt="">
                                        </center>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card card-success">
                                    <div class="card-header">
                                        <h3 class="card-title">Pendidikan Terakhir</h3>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-bordered table-responsive">
                                            <thead>
                                                <tr>
                                                    <th>Pendidikan Terakhir</th>
                                                    <th>Asal Sekolah / Universitas:</th>
                                                    <th>Jurusan / Program Studi</th>
                                                    <th>Nilai Akhir / IPK</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo e($dataDiri->pendidikan_terakhir); ?></td>
                                                    <td><?php echo e($dataDiri->asal_sekolah); ?></td>
                                                    <td><?php echo e($dataDiri->jurusan); ?></td>
                                                    <td><?php echo e($dataDiri->nilai_akhir); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card card-warning">
                                    <div class="card-header">
                                        <h3 class="card-title">Berkas</h3>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-bordered table-responsive">
                                            <thead>
                                                <tr>
                                                    <th>Surat Lamaran</th>
                                                    <th>Curriculum Vitae (CV)</th>
                                                    <th>Pengalaman Kerja</th>
                                                    <th>Portofolio</th>
                                                    <th>KTP</th>
                                                    <th>KK</th>
                                                    <th>Ijazah Terakhir</th>
                                                    <th>Transkrip Nilai</th>
                                                    <th>SKCK</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <?php if($dataDiri->surat_lamaran !='' or $dataDiri->surat_lamaran != null): ?>
                                                            <?php echo e($dataDiri->surat_lamaran); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->cv !='' or $dataDiri->cv != null): ?>
                                                            <?php echo e($dataDiri->cv); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->pengalaman_kerja !='' or $dataDiri->pengalaman_kerja != null): ?>
                                                            <?php echo e($dataDiri->pengalaman_kerja); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->portofolio !='' or $dataDiri->portofolio != null): ?>
                                                            <?php echo e($dataDiri->portofolio); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->ktp !='' or $dataDiri->ktp != null): ?>
                                                            <?php echo e($dataDiri->ktp); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->kk !='' or $dataDiri->kk != null): ?>
                                                            <?php echo e($dataDiri->kk); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->ijazah_terakhir !='' or $dataDiri->ijazah_terakhir != null): ?>
                                                            <?php echo e($dataDiri->ijazah_terakhir); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->transkrip_nilai !='' or $dataDiri->transkrip_nilai != null): ?>
                                                            <?php echo e($dataDiri->transkrip_nilai); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($dataDiri->skck !='' or $dataDiri->skck != null): ?>
                                                            <?php echo e($dataDiri->skck); ?>

                                                        <?php else: ?>
                                                            Belum ada
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="form-group">
                            <strong>Example:</strong>
                            Example
                        </div> -->

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/data-diri/show.blade.php ENDPATH**/ ?>