<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('user_id')); ?>

            <?php echo e(Form::text('user_id', $dataPendidikan->user_id, ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id'])); ?>

            <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pendidikan_terakhir')); ?>

            <?php echo e(Form::text('pendidikan_terakhir', $dataPendidikan->pendidikan_terakhir, ['class' => 'form-control' . ($errors->has('pendidikan_terakhir') ? ' is-invalid' : ''), 'placeholder' => 'Pendidikan Terakhir'])); ?>

            <?php echo $errors->first('pendidikan_terakhir', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('asal_sekolah')); ?>

            <?php echo e(Form::text('asal_sekolah', $dataPendidikan->asal_sekolah, ['class' => 'form-control' . ($errors->has('asal_sekolah') ? ' is-invalid' : ''), 'placeholder' => 'Asal Sekolah'])); ?>

            <?php echo $errors->first('asal_sekolah', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('jurusan')); ?>

            <?php echo e(Form::text('jurusan', $dataPendidikan->jurusan, ['class' => 'form-control' . ($errors->has('jurusan') ? ' is-invalid' : ''), 'placeholder' => 'Jurusan'])); ?>

            <?php echo $errors->first('jurusan', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('nilai_akhir')); ?>

            <?php echo e(Form::text('nilai_akhir', $dataPendidikan->nilai_akhir, ['class' => 'form-control' . ($errors->has('nilai_akhir') ? ' is-invalid' : ''), 'placeholder' => 'Nilai Akhir'])); ?>

            <?php echo $errors->first('nilai_akhir', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/data-pendidikan/form.blade.php ENDPATH**/ ?>