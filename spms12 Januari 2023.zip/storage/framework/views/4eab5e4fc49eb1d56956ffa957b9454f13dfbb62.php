<div class="box box-info padding-1">
    <div class="box-body">
        
        <!-- <div class="form-group">
            <?php echo e(Form::label('kode')); ?>

            <?php echo e(Form::text('kode', $jabatan->kode, ['class' => 'form-control' . ($errors->has('kode') ? ' is-invalid' : ''), 'placeholder' => 'Kode'])); ?>

            <?php echo $errors->first('kode', '<div class="invalid-feedback">:message</div>'); ?>

        </div> -->
        <div class="form-group">
            <label for="">Kode</label>
            <input type="text" class="form-control" placeholder="Kode" name="kode" value="<?php echo e($jabatan->kode); ?>" readonly>
        </div>
        <div class="form-group">
            <label for="">Perusahaan</label>
            <select class="form-control" name="id_perusahaan">
                <?php $__currentLoopData = $perusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowperusahaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($rowperusahaan->id); ?>" <?php if($rowperusahaan->id == $jabatan->id_perusahaan): ?> selected <?php endif; ?>><?php echo e($rowperusahaan->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <?php echo e(Form::label('jabatan')); ?>

            <?php echo e(Form::text('nama', $jabatan->nama, ['class' => 'form-control' . ($errors->has('nama') ? ' is-invalid' : ''), 'placeholder' => 'Nama'])); ?>

            <?php echo $errors->first('nama', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/jabatan/form_edit.blade.php ENDPATH**/ ?>