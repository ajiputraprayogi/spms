<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
            <a href="<?php echo e(url('/backend/home')); ?>" class="nav-link">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>
                    Dashboard
                </p>
            </a>
        </li>
        <?php echo $__env->yieldContent('menu'); ?>
        <!-- <li class="nav-item">
            <a href="<?php echo e(url('/backend/perusahaan')); ?>" class="nav-link">
                <i class="nav-icon fas fa-columns"></i>
                <p>
                    Perusahaan
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('/backend/jabatan')); ?>" class="nav-link">
                <i class="nav-icon fas fa-th"></i>
                <p>
                    Jabatan
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('/backend/soal')); ?>" class="nav-link">
                <i class="nav-icon fas fa-ellipsis-h"></i>
                <p>
                    Soal
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('/backend/data-diri')); ?>" class="nav-link">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    Data Pelamar
                </p>
            </a>
        </li> -->
        <!-- <li class="nav-item">
            <a href="<?php echo e(url('/backend/data-pendidikan')); ?>" class="nav-link">
                <i class="nav-icon fas fa-ellipsis-h"></i>
                <p>
                    Data Pendidikan
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('/backend/upload-berkas')); ?>" class="nav-link">
                <i class="nav-icon fas fa-ellipsis-h"></i>
                <p>
                    Upload Berkas
                </p>
            </a>
        </li> -->
        <!-- <?php if(auth()->user()->can('view-users') ||
            auth()->user()->can('create-users') ||
            auth()->user()->can('edit-users') ||
            auth()->user()->can('delete-users') ||
            auth()->user()->can('view-roles') ||
            auth()->user()->can('create-roles') ||
            auth()->user()->can('edit-roles') ||
            auth()->user()->can('delete-roles') ||
            auth()->user()->can('view-permission') ||
            auth()->user()->can('create-permission') ||
            auth()->user()->can('edit-permission') ||
            auth()->user()->can('delete-permission')): ?>
            <li class="nav-item has-treeview">
                <a href="#" class="nav-link">
                    <i class="nav-icon fas fa-users"></i>
                    <p>
                        User Management
                        <i class="fas fa-angle-left right"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <?php if(auth()->user()->can('view-permission') ||
                        auth()->user()->can('create-permission') ||
                        auth()->user()->can('edit-permission') ||
                        auth()->user()->can('delete-permission')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/backend/permission')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Permission</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(auth()->user()->can('view-roles') ||
                        auth()->user()->can('create-roles') ||
                        auth()->user()->can('edit-roles') ||
                        auth()->user()->can('delete-roles')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/backend/roles')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Roles</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(auth()->user()->can('view-users') ||
                        auth()->user()->can('create-users') ||
                        auth()->user()->can('edit-users') ||
                        auth()->user()->can('delete-users')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/backend/users')); ?>" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Users</p>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?> -->
        <!-- <li class="nav-item">
            <a href="<?php echo e(url('/backend/setting-web')); ?>" class="nav-link">
                <i class="nav-icon fas fa-cog"></i>
                <p>
                    Setting Web
                </p>
            </a>
        </li> -->
        

        
    </ul>
</nav>
<?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/layouts/sidebarUser.blade.php ENDPATH**/ ?>