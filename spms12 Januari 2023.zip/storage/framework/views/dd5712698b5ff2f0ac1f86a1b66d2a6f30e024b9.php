

<?php $__env->startSection('template_title'); ?>
    <?php echo e($dataPendidikan->name ?? 'Show Data Pendidikan'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Data Pendidikan</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('data-pendidikan.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>User Id:</strong>
                            <?php echo e($dataPendidikan->user_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Pendidikan Terakhir:</strong>
                            <?php echo e($dataPendidikan->pendidikan_terakhir); ?>

                        </div>
                        <div class="form-group">
                            <strong>Asal Sekolah:</strong>
                            <?php echo e($dataPendidikan->asal_sekolah); ?>

                        </div>
                        <div class="form-group">
                            <strong>Jurusan:</strong>
                            <?php echo e($dataPendidikan->jurusan); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nilai Akhir:</strong>
                            <?php echo e($dataPendidikan->nilai_akhir); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/data-pendidikan/show.blade.php ENDPATH**/ ?>