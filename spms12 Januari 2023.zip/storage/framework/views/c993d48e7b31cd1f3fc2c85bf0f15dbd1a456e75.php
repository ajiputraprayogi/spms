

<?php $__env->startSection('template_title'); ?>
    Test
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startSection('menu'); ?>
    <li class="nav-item">
        <a href="<?php echo e(url('/test')); ?>" class="nav-link">
            <i class="nav-icon fas fa-columns"></i>
            <p>
                Test Soal
            </p>
        </a>
    </li>
    <?php $__env->stopSection(); ?>
        <?php
        $cek = DB::table('test')->where('id_user', Auth::user()->id)->get();
        if(count($cek) == 0){
            $test = DB::table('soal')->inRandomOrder()->groupby('jenis_soal')->limit(4)->get();
            foreach($test as $rowtest){
                DB::table('test')->insert([
                    'id_user' => Auth::user()->id,
                    'jenis_soal' => $rowtest->jenis_soal,
                    'status' => 'Belum'
                ]);
            }
            header("Refresh:0");
        }else{

        }
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('test.store')); ?>"  role="form" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <?php
                                    $ceksoal = DB::table('test')->where([['id_user', Auth::user()->id],['status','Belum']])->first();
                                ?>
                                <?php if(!empty($ceksoal)): ?>
                                    <div class="box box-info padding-1">
                                        <div class="box-body">
                                            <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowtests): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $soaljenis = DB::table('soal')->where('jenis_soal', $rowtests->jenis_soal)->get();
                                                    foreach($soaljenis as $rowsoaljenis){
                                                        $jumlahsoalabc = $rowsoaljenis->jumlah_soal_abc;
                                                    }
                                                ?>
                                                <?php $no = 1; ?>
                                                
                                                <?php $__currentLoopData = $soaljenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowsoaljenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($rowsoaljenis->tipe_soal == 'Abc'): ?>
                                                <div class="card card-primary">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <input type="hidden" name="id_soal[<?php echo e($rowsoaljenis->id); ?>]" value="<?php echo e($rowsoaljenis->id); ?>">
                                                            <input type="hidden" name="tipe_soal[<?php echo e($rowsoaljenis->id); ?>]" id="tipe_soal" value="Abc" class="form-control">
                                                            <div class="col-md-12">
                                                                <p name="soal[<?php echo e($rowsoaljenis->id); ?>]" id="soal"><?php echo e($no++); ?>. <?php echo e($rowsoaljenis->soal); ?></p>
                                                            </div><br>
                                                            <div class="col-md-6">
                                                                <p name="a[<?php echo e($rowsoaljenis->id); ?>]" id="a">A. <?php echo e($rowsoaljenis->a); ?></p>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <p name="b[<?php echo e($rowsoaljenis->id); ?>]" id="b">B. <?php echo e($rowsoaljenis->b); ?></p>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <p name="c[<?php echo e($rowsoaljenis->id); ?>]" id="c">C. <?php echo e($rowsoaljenis->c); ?></p>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <p name="d[<?php echo e($rowsoaljenis->id); ?>]" id="d">D. <?php echo e($rowsoaljenis->d); ?></p>
                                                            </div>
                                                            <div class="col-md-12"><br>
                                                                <p style="margin-bottom:2px;">Jawab :</p>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="a[<?php echo e($rowsoaljenis->id); ?>]" value="A">
                                                                <label for="a[<?php echo e($rowsoaljenis->id); ?>]">A</label>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="b[<?php echo e($rowsoaljenis->id); ?>]" value="B">
                                                                <label for="b[<?php echo e($rowsoaljenis->id); ?>]">B</label>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="c[<?php echo e($rowsoaljenis->id); ?>]" value="C">
                                                                <label for="c[<?php echo e($rowsoaljenis->id); ?>]">C</label>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="d[<?php echo e($rowsoaljenis->id); ?>]" value="D">
                                                                <label for="d[<?php echo e($rowsoaljenis->id); ?>]">D</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                <?php $__currentLoopData = $soaljenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowsoaljenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($rowsoaljenis->tipe_soal == 'YaTidak'): ?>
                                                <div class="card card-warning">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <input type="hidden" name="id_soal[<?php echo e($rowsoaljenis->id); ?>]" value="<?php echo e($rowsoaljenis->id); ?>">
                                                            <input type="hidden" name="tipe_soal[<?php echo e($rowsoaljenis->id); ?>]" id="tipe_soal" value="YaTidak" class="form-control">
                                                            <div class="col-md-12">
                                                                <p name="soal[<?php echo e($rowsoaljenis->id); ?>]" id="soal[<?php echo e($rowsoaljenis->id); ?>]"><?php echo e($no++); ?>. <?php echo e($rowsoaljenis->soal); ?></p>
                                                            </div><br>
                                                            <div class="col-md-12"><br>
                                                                <p style="margin-bottom:2px;">Jawab :</p>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="ya[<?php echo e($rowsoaljenis->id); ?>]" value="Ya">
                                                                <label for="ya[<?php echo e($rowsoaljenis->id); ?>]">Ya</label>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="tidak[<?php echo e($rowsoaljenis->id); ?>]" value="Tidak">
                                                                <label for="tidak[<?php echo e($rowsoaljenis->id); ?>]">Tidak</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="box-footer mt20">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="box">
                                        <?php
                                        $hasil = DB::table('test')->where('id_user', Auth::user()->id)->get();
                                        ?>
                                        <?php $no=1; ?>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Tahapan</th>
                                                    <th>Jenis Soal</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowhasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo e($no++); ?></td>
                                                    <td><?php echo e($rowhasil->jenis_soal); ?></td>
                                                    <td><?php echo e($rowhasil->status); ?></td>
                                                </tr>
                                            </tbody>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                <?php endif; ?>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- <div class="container-fluid">
        <div class="row">
            <?php if($message = Session::get('success')): ?>
                <div class="col-md-12">
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php endif; ?>
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Test')); ?>

                            </span>

                             <div class="float-right">
                                <a href="<?php echo e(route('test.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  <?php echo e(__('Create New')); ?>

                                </a>
                              </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <form method="get">
                                    <div class="input-group input-group-sm">
                                        <input type="text" name="search" class="form-control">
                                        <span class="input-group-append">
                                            <button type="submit" class="btn btn-info btn-flat">Search</button>
                                            <a href="<?php echo e(route('test.index')); ?>" class="btn btn-secondary btn-flat">Reset</a>
                                    </span>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>

										<th>Id User</th>
										<th>Jenis Soal</th>
										<th>Status</th>

                                        <th class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>

											<td><?php echo e($test->id_user); ?></td>
											<td><?php echo e($test->jenis_soal); ?></td>
											<td><?php echo e($test->status); ?></td>

                                            <td class="text-center">
                                                <form action="<?php echo e(route('test.destroy',$test->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('test.show',$test->id)); ?>"><i class="fa fa-fw fa-eye"></i> Show</a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('test.edit',$test->id)); ?>"><i class="fa fa-fw fa-edit"></i> Edit</a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $tests->links(); ?>

            </div>
        </div>
    </div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/test/index.blade.php ENDPATH**/ ?>