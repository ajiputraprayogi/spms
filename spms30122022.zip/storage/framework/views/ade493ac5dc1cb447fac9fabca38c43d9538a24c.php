

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_title'); ?>
    Setting Web
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluit">
            <div class="row">
                <?php if(session('status')): ?>
                    <div class="col-lg-12">
                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h4>Info!</h4>
                            <?php echo e(session('status')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-12">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card card-warning">
                        <div class="card-header">
                            <h3 class="card-title">Edit Setting</h3>
                        </div>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form method="POST" role="form" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">App Name</label>
                                                <input type="text" class="form-control" name="app_name"
                                                    value="<?php echo e($row->app_name); ?>" required autofocus>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">App Alias Name</label>
                                                <input type="text" class="form-control" name="app_alias"
                                                    value="<?php echo e($row->app_alias); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Sidebar Type</label>
                                                <select name="sidebar_type" class="form-control">
                                                    <option value="dark"
                                                        <?php if($row->sidebar_type == 'dark'): ?> selected <?php endif; ?>>dark</option>
                                                    <option value="light"
                                                        <?php if($row->sidebar_type == 'light'): ?> selected <?php endif; ?>>light</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Navbar Color</label>
                                                <select name="navbar_color" class="form-control">
                                                    <option class="bg-primary" value="primary"
                                                        <?php if($row->navbar_color == 'primary'): ?> selected <?php endif; ?>>primary</option>
                                                    <option class="bg-secondary" value="secondary"
                                                        <?php if($row->navbar_color == 'secondary'): ?> selected <?php endif; ?>>secondary</option>
                                                    <option class="bg-info" value="info"
                                                        <?php if($row->navbar_color == 'info'): ?> selected <?php endif; ?>>info</option>
                                                    <option class="bg-success" value="success"
                                                        <?php if($row->navbar_color == 'success'): ?> selected <?php endif; ?>>success</option>
                                                    <option class="bg-danger" value="danger"
                                                        <?php if($row->navbar_color == 'danger'): ?> selected <?php endif; ?>>danger</option>
                                                    <option class="bg-indigo" value="indigo"
                                                        <?php if($row->navbar_color == 'indigo'): ?> selected <?php endif; ?>>indigo</option>
                                                    <option class="bg-purple" value="purple"
                                                        <?php if($row->navbar_color == 'purple'): ?> selected <?php endif; ?>>purple</option>
                                                    <option class="bg-pink" value="pink"
                                                        <?php if($row->navbar_color == 'pink'): ?> selected <?php endif; ?>>pink</option>
                                                    <option class="bg-navy" value="navy"
                                                        <?php if($row->navbar_color == 'navy'): ?> selected <?php endif; ?>>navy</option>
                                                    <option class="bg-lightblue" value="lightblue"
                                                        <?php if($row->navbar_color == 'lightblue'): ?> selected <?php endif; ?>>lightblue
                                                    </option>
                                                    <option class="bg-teal" value="teal"
                                                        <?php if($row->navbar_color == 'teal'): ?> selected <?php endif; ?>>teal</option>
                                                    <option class="bg-cyan" value="cyan"
                                                        <?php if($row->navbar_color == 'cyan'): ?> selected <?php endif; ?>>cyan</option>
                                                    <option class="bg-dark" value="dark"
                                                        <?php if($row->navbar_color == 'dark'): ?> selected <?php endif; ?>>dark</option>
                                                    <option class="bg-gray" value="gray"
                                                        <?php if($row->navbar_color == 'gray'): ?> selected <?php endif; ?>>gray</option>
                                                    <option class="bg-light" value="light"
                                                        <?php if($row->navbar_color == 'light'): ?> selected <?php endif; ?>>light</option>
                                                    <option class="bg-warning" value="warning"
                                                        <?php if($row->navbar_color == 'warning'): ?> selected <?php endif; ?>>warning</option>
                                                    <option class="bg-orange" value="orange"
                                                        <?php if($row->navbar_color == 'orange'): ?> selected <?php endif; ?>>orange</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Navbar Type</label>
                                                <select name="navbar_type" class="form-control">
                                                    <option value="dark"
                                                        <?php if($row->navbar_type == 'dark'): ?> selected <?php endif; ?>>dark</option>
                                                    <option value="light"
                                                        <?php if($row->navbar_type == 'light'): ?> selected <?php endif; ?>>light</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Brand Logo Bg Color</label>
                                                <select name="brand_logo_bg_color" class="form-control">
                                                    <option class="bg-primary" value="primary"
                                                        <?php if($row->logo_bg_color == 'primary'): ?> selected <?php endif; ?>>primary</option>
                                                    <option class="bg-secondary" value="secondary"
                                                        <?php if($row->logo_bg_color == 'secondary'): ?> selected <?php endif; ?>>secondary
                                                    </option>
                                                    <option class="bg-info" value="info"
                                                        <?php if($row->logo_bg_color == 'info'): ?> selected <?php endif; ?>>info</option>
                                                    <option class="bg-success" value="success"
                                                        <?php if($row->logo_bg_color == 'success'): ?> selected <?php endif; ?>>success</option>
                                                    <option class="bg-danger" value="danger"
                                                        <?php if($row->logo_bg_color == 'danger'): ?> selected <?php endif; ?>>danger</option>
                                                    <option class="bg-indigo" value="indigo"
                                                        <?php if($row->logo_bg_color == 'indigo'): ?> selected <?php endif; ?>>indigo</option>
                                                    <option class="bg-purple" value="purple"
                                                        <?php if($row->logo_bg_color == 'purple'): ?> selected <?php endif; ?>>purple</option>
                                                    <option class="bg-pink" value="pink"
                                                        <?php if($row->logo_bg_color == 'pink'): ?> selected <?php endif; ?>>pink</option>
                                                    <option class="bg-navy" value="navy"
                                                        <?php if($row->logo_bg_color == 'navy'): ?> selected <?php endif; ?>>navy</option>
                                                    <option class="bg-lightblue" value="lightblue"
                                                        <?php if($row->logo_bg_color == 'lightblue'): ?> selected <?php endif; ?>>lightblue
                                                    </option>
                                                    <option class="bg-teal" value="teal"
                                                        <?php if($row->logo_bg_color == 'teal'): ?> selected <?php endif; ?>>teal</option>
                                                    <option class="bg-cyan" value="cyan"
                                                        <?php if($row->logo_bg_color == 'cyan'): ?> selected <?php endif; ?>>cyan</option>
                                                    <option class="bg-dark" value="dark"
                                                        <?php if($row->logo_bg_color == 'dark'): ?> selected <?php endif; ?>>dark</option>
                                                    <option class="bg-gray" value="gray"
                                                        <?php if($row->logo_bg_color == 'gray'): ?> selected <?php endif; ?>>gray</option>
                                                    <option class="bg-light" value="light"
                                                        <?php if($row->logo_bg_color == 'light'): ?> selected <?php endif; ?>>light</option>
                                                    <option class="bg-warning" value="warning"
                                                        <?php if($row->logo_bg_color == 'warning'): ?> selected <?php endif; ?>>warning</option>
                                                    <option class="bg-orange" value="orange"
                                                        <?php if($row->logo_bg_color == 'orange'): ?> selected <?php endif; ?>>orange</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Brand Text Type</label>
                                                <select name="brand_type" class="form-control">
                                                    <option value="dark"
                                                        <?php if($row->brand_type == 'dark'): ?> selected <?php endif; ?>>dark</option>
                                                    <option value="light"
                                                        <?php if($row->brand_type == 'light'): ?> selected <?php endif; ?>>light</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">App Logo</label>
                                                <input type="file" class="form-control" name="app_logo"
                                                    accept="image/png, image/jpg, image/jpeg">
                                                <a href="<?php echo e(asset('/images/setting/'.$row->app_logo)); ?>" target="blank()"> <i class="fas fa-image"></i> Old Logo</a>
                                            </div>
                                        </div>
                                        <input type="hidden" value="<?php echo e($row->id); ?>" name="kode">
                                        <input type="hidden" value="<?php echo e($row->app_logo); ?>" name="old_logo">
                                </div>
                                <div class="card-footer">
                                    <button type="reset" onclick="history.go(-1)"
                                        class="btn btn-danger">Kembali</button>
                                    <button type="submit" class="btn btn-primary float-right">Simpan</button>
                                </div>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js_in'); ?>
    <script src="<?php echo e(asset('assets/customjs/users/users_input.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/settingweb/index.blade.php ENDPATH**/ ?>