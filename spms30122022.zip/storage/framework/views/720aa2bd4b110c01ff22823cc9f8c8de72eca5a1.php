

<?php $__env->startSection('template_title'); ?>
    <?php echo e($uploadBerkas->name ?? 'Show Upload Berkas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Upload Berkas</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('upload-berkas.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>User Id:</strong>
                            <?php echo e($uploadBerkas->user_id); ?>

                        </div>
                        <div class="form-group">
                            <strong>Surat Lamaran:</strong>
                            <?php echo e($uploadBerkas->surat_lamaran); ?>

                        </div>
                        <div class="form-group">
                            <strong>Cv:</strong>
                            <?php echo e($uploadBerkas->cv); ?>

                        </div>
                        <div class="form-group">
                            <strong>Pengalaman Kerja:</strong>
                            <?php echo e($uploadBerkas->pengalaman_kerja); ?>

                        </div>
                        <div class="form-group">
                            <strong>Portofolio:</strong>
                            <?php echo e($uploadBerkas->portofolio); ?>

                        </div>
                        <div class="form-group">
                            <strong>Ktp:</strong>
                            <?php echo e($uploadBerkas->ktp); ?>

                        </div>
                        <div class="form-group">
                            <strong>Kk:</strong>
                            <?php echo e($uploadBerkas->kk); ?>

                        </div>
                        <div class="form-group">
                            <strong>Ijazah Terakhir:</strong>
                            <?php echo e($uploadBerkas->ijazah_terakhir); ?>

                        </div>
                        <div class="form-group">
                            <strong>Transkrip Nilai:</strong>
                            <?php echo e($uploadBerkas->transkrip_nilai); ?>

                        </div>
                        <div class="form-group">
                            <strong>Skck:</strong>
                            <?php echo e($uploadBerkas->skck); ?>

                        </div>
                        <div class="form-group">
                            <strong>Foto:</strong>
                            <?php echo e($uploadBerkas->foto); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/upload-berkas/show.blade.php ENDPATH**/ ?>