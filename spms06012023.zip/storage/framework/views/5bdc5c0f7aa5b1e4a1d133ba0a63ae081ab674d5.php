<!DOCTYPE html>
<html>

<?php
$data_setting_web = DB::table('setting_web')->orderby('id','desc')->limit(1)->get();
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($row_data_setting_web->app_alias); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/adminlte.min.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <?php echo $__env->yieldPushContent('cs_in'); ?>
</head>
<body class="hold-transition sidebar-mini sidebar-collapse">
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand <?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> navbar-<?php echo e($row_data_setting_web->navbar_color); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> navbar-<?php echo e($row_data_setting_web->navbar_type); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                            class="fas fa-bars"></i></a>
                </li>
            </ul>

            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#">
                        <i class="far fa-user"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                        <span class="dropdown-item dropdown-header"><?php echo e(Auth::user()->name); ?></span>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fa fa-power-off mr-2"></i> Logout
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                        <div class="dropdown-divider"></div>
                        <a href="<?php echo e(url('/backend/home/edit-profile')); ?>" class="dropdown-item">
                            <i class="fas fa-cog mr-2"></i> Edit Akun
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <aside class="main-sidebar <?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> sidebar-<?php echo e($row_data_setting_web->sidebar_type); ?>-primary <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> elevation-4">
            <a href="<?php echo e(url('/home')); ?>" class="brand-link <?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> navbar-<?php echo e($row_data_setting_web->logo_bg_color); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                <?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <img src="<?php echo e(asset('images/setting/'.$row_data_setting_web->app_logo)); ?>" alt="brand Logo"
                class="brand-image img-circle elevation-3" style="opacity: .8"> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <span class="brand-text font-weight-light <?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> text-<?php echo e($row_data_setting_web->brand_type); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"><?php $__currentLoopData = $data_setting_web; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_data_setting_web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($row_data_setting_web->app_name); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
            </a>

            <div class="sidebar">
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image">
                        <img src="<?php echo e(asset('assets/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2"
                            alt="User Image">
                    </div>
                    <div class="info">
                        <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
                    </div>
                </div>
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </aside>
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluit">
                    <div class="row mb-2">
                        <div class="col-sm-12 pl-3">
                            <h1 class="m-0 text-dark"> <?php echo $__env->yieldContent('template_title'); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/adminlte.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
    <?php echo $__env->yieldPushContent('js_in'); ?>
</body>

</html>
<?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/layouts/app.blade.php ENDPATH**/ ?>