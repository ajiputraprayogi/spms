<div id="divsatu" class="box box-info padding-1">
    <div class="box-body">
        
        <!-- <div class="form-group">
            <?php echo e(Form::label('jenis_soal')); ?>

            <?php echo e(Form::text('jenis_soal', $soal->jenis_soal, ['class' => 'form-control' . ($errors->has('jenis_soal') ? ' is-invalid' : ''), 'placeholder' => 'Jenis Soal'])); ?>

            <?php echo $errors->first('jenis_soal', '<div class="invalid-feedback">:message</div>'); ?>

        </div> -->
        <div class="form-group">
            <label for="">Jenis Soal</label>
            <input type="text" name="jenis_soal" id="jenis_soal" value="<?php echo e($soal->jenis_soal); ?>" placeholder="Jenis Soal" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Jumlah Soal ABC</label>
            <input type="number" name="jumlah_soal_abc" id="jumlah_soal_abc" value="<?php echo e($soal->jumlah_soal_abc); ?>" placeholder="Jumlah Soal ABC" class="form-control">
        </div>
        <div class="form-group">
            <label for="">Jumlah Soal Ya/Tidak</label>
            <input type="number" name="jumlah_soal_yt" id="jumlah_soal_yt" value="<?php echo e($soal->jumlah_soal_yt); ?>" placeholder="Jumlah Soal Ya/Tidak" class="form-control">
        </div>
        <div class="form-group">
            <?php echo e(Form::label('status')); ?>

            <select name="status" id="" class="form-control">
                <option <?php if($soal->status == 'Aktif'): ?>selected <?php endif; ?>>Aktif</option>
                <option <?php if($soal->status == 'Nonaktif'): ?>selected <?php endif; ?>>Nonaktif</option>
            </select>
        </div>
        <div class="form-group">
            <label for="">Minimal Score</label>
            <input type="number" name="minimal_score" id="minimal_score" value="<?php echo e($soal->minimal_score); ?>" placeholder="Minimal Score" class="form-control">
        </div>

    </div>
    <div class="box-footer mt20">
        <button id="buttonsatu" type="button" onclick="next()" class="btn btn-primary">Next</button>
    </div>
</div>
<div id="divdua" style="display:show;" class="box box-info padding-1">
    <div id="divbody" class="box-body">
        
        <?php
            $soaljenis = DB::table('soal')->where('jenis_soal', $soal->jenis_soal)->get();
            $jumlahsoalabc = $soal->jumlah_soal_abc;
        ?>
        <?php $no = 1; ?>
        <?php $__currentLoopData = $soaljenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowsoaljenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($rowsoaljenis->tipe_soal == 'Abc'): ?>
        <div class="card card-primary">
            <div class="card-header">
                Soal ABC
            </div>
            <div class="card-body">
                <div class="row">
                    <input type="hidden" name="id_soal[<?php echo e($rowsoaljenis->id); ?>]" value="<?php echo e($rowsoaljenis->id); ?>">
                    <input type="hidden" name="tipe_soal[<?php echo e($rowsoaljenis->id); ?>]" id="tipe_soal" value="Abc" class="form-control">
                    <div class="col-md-12">
                        <label for="">Soal <?php echo e($no++); ?></label>
                        <textarea name="soal[<?php echo e($rowsoaljenis->id); ?>]" id="soal" rows="2" class="form-control"><?php echo e($rowsoaljenis->soal); ?></textarea>
                    </div><br>
                    <div class="col-md-6">
                        <label for="">A.</label>
                        <textarea name="a[<?php echo e($rowsoaljenis->id); ?>]" id="a" rows="1" class="form-control"><?php echo e($rowsoaljenis->a); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label for="">B.</label>
                        <textarea name="b[<?php echo e($rowsoaljenis->id); ?>]" id="b" rows="1" class="form-control"><?php echo e($rowsoaljenis->b); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label for="">C.</label>
                        <textarea name="c[<?php echo e($rowsoaljenis->id); ?>]" id="c" rows="1" class="form-control"><?php echo e($rowsoaljenis->c); ?></textarea>
                    </div>
                    <div class="col-md-6">
                        <label for="">D.</label>
                        <textarea name="d[<?php echo e($rowsoaljenis->id); ?>]" id="d" rows="1" class="form-control"><?php echo e($rowsoaljenis->d); ?></textarea>
                    </div>
                    <div class="col-md-12"><br>
                        <p style="margin-bottom:2px;">Jawaban :</p>
                    </div>
                    <div class="col-md-1">
                        <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="a[<?php echo e($rowsoaljenis->id); ?>]" value="A" <?php if($rowsoaljenis->jawaban == 'A'): ?> checked <?php endif; ?>>
                        <label for="a[<?php echo e($rowsoaljenis->id); ?>]">A</label>
                    </div>
                    <div class="col-md-1">
                        <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="b[<?php echo e($rowsoaljenis->id); ?>]" value="B" <?php if($rowsoaljenis->jawaban == 'B'): ?> checked <?php endif; ?>>
                        <label for="b[<?php echo e($rowsoaljenis->id); ?>]">B</label>
                    </div>
                    <div class="col-md-1">
                        <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="c[<?php echo e($rowsoaljenis->id); ?>]" value="C" <?php if($rowsoaljenis->jawaban == 'C'): ?> checked <?php endif; ?>>
                        <label for="c[<?php echo e($rowsoaljenis->id); ?>]">C</label>
                    </div>
                    <div class="col-md-1">
                        <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="d[<?php echo e($rowsoaljenis->id); ?>]" value="D" <?php if($rowsoaljenis->jawaban == 'D'): ?> checked <?php endif; ?>>
                        <label for="d[<?php echo e($rowsoaljenis->id); ?>]">D</label>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php $__currentLoopData = $soaljenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowsoaljenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($rowsoaljenis->tipe_soal == 'YaTidak'): ?>
        <div class="card card-warning">
            <div class="card-header">
                Soal Ya/Tidak
            </div>
            <div class="card-body">
                <div class="row">
                    <input type="hidden" name="id_soal[<?php echo e($rowsoaljenis->id); ?>]" value="<?php echo e($rowsoaljenis->id); ?>">
                    <input type="hidden" name="tipe_soal[<?php echo e($rowsoaljenis->id); ?>]" id="tipe_soal" value="YaTidak" class="form-control">
                    <div class="col-md-12">
                        <label for="">Soal <?php echo e($no++); ?></label>
                        <textarea name="soal[<?php echo e($rowsoaljenis->id); ?>]" id="soal[<?php echo e($rowsoaljenis->id); ?>]" rows="2" class="form-control"><?php echo e($rowsoaljenis->soal); ?></textarea>
                    </div><br>
                    <div class="col-md-12"><br>
                        <p style="margin-bottom:2px;">Jawaban :</p>
                    </div>
                    <div class="col-md-1">
                        <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="ya[<?php echo e($rowsoaljenis->id); ?>]" value="Ya" <?php if($rowsoaljenis->jawaban == 'Ya'): ?> checked <?php endif; ?>>
                        <label for="ya[<?php echo e($rowsoaljenis->id); ?>]">Ya</label>
                    </div>
                    <div class="col-md-1">
                        <input type="radio" name="jawaban[<?php echo e($rowsoaljenis->id); ?>]" id="tidak[<?php echo e($rowsoaljenis->id); ?>]" value="Tidak" <?php if($rowsoaljenis->jawaban == 'Tidak'): ?> checked <?php endif; ?>>
                        <label for="tidak[<?php echo e($rowsoaljenis->id); ?>]">Tidak</label>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="box-footer mt20">
        <button type="button" onclick="back()" class="btn btn-danger">Back</button>
        <button id="buttondua" type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/soal/form_edit.blade.php ENDPATH**/ ?>