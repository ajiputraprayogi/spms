<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('user_id')); ?>

            <?php echo e(Form::text('user_id', $uploadBerkas->user_id, ['class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''), 'placeholder' => 'User Id'])); ?>

            <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('surat_lamaran')); ?>

            <?php echo e(Form::text('surat_lamaran', $uploadBerkas->surat_lamaran, ['class' => 'form-control' . ($errors->has('surat_lamaran') ? ' is-invalid' : ''), 'placeholder' => 'Surat Lamaran'])); ?>

            <?php echo $errors->first('surat_lamaran', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cv')); ?>

            <?php echo e(Form::text('cv', $uploadBerkas->cv, ['class' => 'form-control' . ($errors->has('cv') ? ' is-invalid' : ''), 'placeholder' => 'Cv'])); ?>

            <?php echo $errors->first('cv', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pengalaman_kerja')); ?>

            <?php echo e(Form::text('pengalaman_kerja', $uploadBerkas->pengalaman_kerja, ['class' => 'form-control' . ($errors->has('pengalaman_kerja') ? ' is-invalid' : ''), 'placeholder' => 'Pengalaman Kerja'])); ?>

            <?php echo $errors->first('pengalaman_kerja', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('portofolio')); ?>

            <?php echo e(Form::text('portofolio', $uploadBerkas->portofolio, ['class' => 'form-control' . ($errors->has('portofolio') ? ' is-invalid' : ''), 'placeholder' => 'Portofolio'])); ?>

            <?php echo $errors->first('portofolio', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('ktp')); ?>

            <?php echo e(Form::text('ktp', $uploadBerkas->ktp, ['class' => 'form-control' . ($errors->has('ktp') ? ' is-invalid' : ''), 'placeholder' => 'Ktp'])); ?>

            <?php echo $errors->first('ktp', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('kk')); ?>

            <?php echo e(Form::text('kk', $uploadBerkas->kk, ['class' => 'form-control' . ($errors->has('kk') ? ' is-invalid' : ''), 'placeholder' => 'Kk'])); ?>

            <?php echo $errors->first('kk', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('ijazah_terakhir')); ?>

            <?php echo e(Form::text('ijazah_terakhir', $uploadBerkas->ijazah_terakhir, ['class' => 'form-control' . ($errors->has('ijazah_terakhir') ? ' is-invalid' : ''), 'placeholder' => 'Ijazah Terakhir'])); ?>

            <?php echo $errors->first('ijazah_terakhir', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('transkrip_nilai')); ?>

            <?php echo e(Form::text('transkrip_nilai', $uploadBerkas->transkrip_nilai, ['class' => 'form-control' . ($errors->has('transkrip_nilai') ? ' is-invalid' : ''), 'placeholder' => 'Transkrip Nilai'])); ?>

            <?php echo $errors->first('transkrip_nilai', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('skck')); ?>

            <?php echo e(Form::text('skck', $uploadBerkas->skck, ['class' => 'form-control' . ($errors->has('skck') ? ' is-invalid' : ''), 'placeholder' => 'Skck'])); ?>

            <?php echo $errors->first('skck', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('foto')); ?>

            <?php echo e(Form::text('foto', $uploadBerkas->foto, ['class' => 'form-control' . ($errors->has('foto') ? ' is-invalid' : ''), 'placeholder' => 'Foto'])); ?>

            <?php echo $errors->first('foto', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/upload-berkas/form.blade.php ENDPATH**/ ?>