

<?php $__env->startSection('template_title'); ?>
    <?php echo e($perusahaan->name ?? 'Show Perusahaan'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Perusahaan</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('perusahaan.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Kode:</strong>
                            <?php echo e($perusahaan->kode); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nama:</strong>
                            <?php echo e($perusahaan->nama); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\spms\resources\views/perusahaan/show.blade.php ENDPATH**/ ?>